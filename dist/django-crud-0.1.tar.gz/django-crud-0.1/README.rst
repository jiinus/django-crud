=====
Crud
=====

Crud is a simple Django app to implement serializable and
trackable abstract base models.

Quick start
-----------

1. Import "crud"

2. Extend crud.CRUModel for permanently deletable models and crud.CRUDModel for setting a flag when deleted
